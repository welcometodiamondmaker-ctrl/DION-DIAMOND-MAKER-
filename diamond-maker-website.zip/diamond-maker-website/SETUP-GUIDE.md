# Diamond Maker Website — Pura Setup Guide

Ye guide aapko A se Z tak le jayegi: website live karna, domain lena, aur payment connect karna.

---

## FOLDER ME KYA HAI

```
diamond-maker-website/
├── index.html          ← Pura website (1 hi file me sab kuch)
└── images/
    ├── logo_full.webp
    ├── glowe_hero.webp
    ├── oriva7_bottle.webp
    ├── oriva7_box_full.webp
    └── combo_kit.webp
```

Is poore folder ko as-it-is upload karna hai. Kuch bhi alag se download/install nahi karna.

---

## STEP 1: Website ko FREE me LIVE karna (Netlify)

1. Jaayein **https://app.netlify.com/signup**
2. "Sign up with Google" se login karein (sabse aasan, credit card nahi chahiye)
3. Login hone ke baad dashboard khulega. Wahan ek box dikhega likha hua:
   **"Drag and drop your site output folder here"**
4. Apne computer me `diamond-maker-website` folder dhundein, aur use **seedha browser me drag karke us box me drop kar dein**
5. 10-20 second me upload ho jayega aur ek random link milega jaisे:
   `https://random-name-123.netlify.app`
6. **Bas — aapki website LIVE ho gayi!** Is link ko khol kar check kar lijiye mobile aur laptop dono pe.

### Site ka naam thoda better karna ho (free me):
- Netlify dashboard me **Site settings → Change site name**
- Naam daalein jaise `diamondmaker` → link banega `https://diamondmaker.netlify.app`

---

## STEP 2: Apna Domain Lena (diamondmaker.in jaisa)

Aapke paas already `diamondmaker.in` domain hai (packaging pe likha hai), to pehle ye check karein ki wo already registered hai ya nahi:

1. Jaayein **https://www.namecheap.com**
2. Search box me `diamondmaker.in` daal kar check karein
3. **Agar already available/owned hai aapke paas** → seedha Step 3 pe jaayein (domain connect karna)
4. **Agar available hai aur lena hai** → ₹600-900/year me buy kar lein (Namecheap ya GoDaddy se)

### Domain ko Netlify se Connect karna:
1. Netlify dashboard → **Domain settings → Add a domain**
2. Apna domain daalein (`diamondmaker.in`)
3. Netlify aapko 2 cheezein dega — Nameservers ya DNS records (A record + CNAME)
4. Jahan se domain khareeda hai (Namecheap/GoDaddy), wahan ke **DNS settings** me jaake ye records daal dein
5. 1-24 ghante me domain live ho jayega (DNS propagate hone me time lagta hai)

> 💡 Agar confuse ho jayein is step pe, Netlify ka apna step-by-step wizard follow kar lein — wo bilkul guide karta hai click-by-click.

---

## STEP 3: Razorpay Payment Connect Karna

Aapka Razorpay account hai but **KYC pending** hai — pehle wo complete karna padega, tabhi real payment aa payega.

### KYC complete karne ke liye:
1. Razorpay Dashboard me login karein → **https://dashboard.razorpay.com**
2. Upar "Activate Account" ya "Complete KYC" banner dikhega
3. Ye documents chahiye honge (company ke):
   - PAN Card (Dion Diamond Maker Private Limited ka)
   - Company incorporation certificate / GST certificate
   - Bank account details (current account, company ke naam pe)
   - Authorized signatory ka Aadhar/PAN
4. Submit karne ke baad usually **2-5 working days** me approve ho jata hai

### KYC hone ke baad — Website me Razorpay Key daalna:
1. Razorpay Dashboard → **Settings → API Keys → Generate Key**
2. Aapko milega: **Key ID** (jaise `rzp_live_AbCd1234...`)
3. `index.html` file kholein (kisi bhi text editor me — Notepad bhi chalega)
4. **Ctrl+F** se search karein: `rzp_test_YOUR_KEY_HERE`
5. Use apni Key ID se replace kar dein
6. File save karke dubara Netlify pe upload kar dein (drag-drop wahi se)

**Jab tak KYC pending hai:** Customers "Buy Now — Pay Online" dabayenge to ek polite message dikhega ki abhi payment setup ho raha hai, aur "Order via WhatsApp" button already fully working hai — to aap shuru me sirf WhatsApp se orders le sakte hain, koi loss nahi.

---

## STEP 4: WhatsApp Number Check Karein

Website me already aapka number `+91 74208 24050` daala hua hai "Order via WhatsApp" buttons me. Agar koi alag number use karna hai order lene ke liye, batayein, main update kar dunga.

---

## Website me kya kya hai (Quick Summary)

✅ Dono products — **GLOWE Face Serum** (₹1,199) aur **ORIVA7 Capsules** (₹2,299)
✅ **Combo Kit** bhi add kiya hai (₹3,498) — packaging me dikha tha
✅ Har product ka pura ingredient list (collapsible "+" button se khulta hai)
✅ "Buy Now" (Razorpay) + "Order via WhatsApp" — dono options har product pe
✅ Mobile-friendly — phone pe bhi sahi dikhegi
✅ WhatsApp floating button — har page pe corner me
✅ Company details, address, FAQ — sab footer aur FAQ section me

---

## Agar kabhi update karna ho (price, text, photo)

`index.html` file ek simple text file hai. Kisi bhi text editor (Notepad, VS Code) me kholiye:
- Price badalni ho → `₹1,199` jaisa text dhundh kar badal dijiye
- Naya text → seedha edit karke save kar dijiye
- Naya photo → `images` folder me daal kar, HTML me uska naam reference kar dijiye

Agar ye khud karne me dikkat ho, mujhe bata dijiye — main update kar dunga.

---

## Koi Sawaal Ho To

Bas mujhe yahin chat me bata dijiye — agla step, koi error, ya design me koi change, sab kar denge.
